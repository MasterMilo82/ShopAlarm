<?php declare(strict_types=1);

namespace FabianD\Subscriber;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\BadResponseException;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\ServerException;
use Shopware\Core\Checkout\Order\Aggregate\OrderTransaction\OrderTransactionStates;
use Shopware\Core\System\StateMachine\Event\StateMachineStateChangeEvent;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class OrderPaidSubscriber implements EventSubscriberInterface
{

    private ?string $webhookUrl;

    public function __construct(SystemConfigService $config)
    {
        $this->webhookUrl = $config->get('ShopAlarm.config.webhookUrl');
    }

    public static function getSubscribedEvents(): array
    {
        return [
            'state_machine.order_transaction.state_changed' => 'onOrderTransactionChanged'
        ];
    }

    public function onOrderTransactionChanged(StateMachineStateChangeEvent $event): void
    {
        if (
            $event->getTransitionSide() != StateMachineStateChangeEvent::STATE_MACHINE_TRANSITION_SIDE_ENTER ||
            $event->getStateName()      != OrderTransactionStates::STATE_PAID
        ) {
            return;
        }

        // Order paid
        if(empty($this->webhookUrl)){
            return;
        }

        // Post to $webhookUrl
        $success = $this->sendPostRequest();
        if(!$success){
            $this->logError("Failed to send webhook");
        }
    }

    private function sendPostRequest(): bool
    {
        $client = new Client();

        try {
            $response = $client->post($this->webhookUrl, [
                'timeout' => 10,
                'verify' => true,
            ]);

            $statusCode = $response->getStatusCode();

            if ($statusCode >= 200 && $statusCode < 300) {
                return true;
            } else {
                return false;
            }

        } catch (ClientException $e) {
            // Handles 4xx client errors (e.g., 400 Bad Request, 401 Unauthorized, 404 Not Found)
            $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : 'N/A';
            $responseBody = $e->hasResponse() ? (string) $e->getResponse()->getBody() : 'No response body';

            $this->logError("Client Error ({$statusCode}): " . $e->getMessage());
            $this->logError("Response Body: {$responseBody}");
        } catch (ServerException $e) {
            // Handles 5xx server errors (e.g., 500 Internal Server Error, 503 Service Unavailable)
            $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : 'N/A';
            $responseBody = $e->hasResponse() ? (string) $e->getResponse()->getBody() : 'No response body';

            $this->logError("Client Error ({$statusCode}): " . $e->getMessage());
            $this->logError("Response Body: {$responseBody}");
        } catch (ConnectException $e) {
            // Handles network errors (e.g., DNS resolution failure, connection timeout)
            $this->logError("Connection Error: " . $e->getMessage());
        } catch (BadResponseException $e) {
            // General catch-all for bad responses if specific Client/Server exceptions
            // don't cover everything, though they usually do.
            $statusCode = $e->hasResponse() ? $e->getResponse()->getStatusCode() : 'N/A';
            $responseBody = $e->hasResponse() ? (string) $e->getResponse()->getBody() : 'No response body';

            $this->logError("Bad Response Error ({$statusCode}): " . $e->getMessage());
            $this->logError("Response Body: {$responseBody}");
        } catch (GuzzleException $e) {
            // Catch any other guzzle exceptions
            $this->logError("An unexpected guzzle error occurred: " . $e->getMessage());
        } catch (\Exception $e) {
            // Catch any other unexpected exceptions
            $this->logError("An unexpected error occurred: " . $e->getMessage());
        }

        return false;
    }

    private function logError(string|array $error): void
    {
        if(is_array($error)){
            $data = json_encode($error);
        }else{
            $data = $error;
        }
        file_put_contents(SHOP_ALARM_DEBUG_FILE, $data . PHP_EOL, FILE_APPEND);
    }

}
